"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="fixed w-full top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">A</span>
            </div>
            <span className="text-xl font-serif font-bold text-foreground hidden sm:inline">ABC Hotel</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-foreground hover:text-primary transition-colors">
              Giới thiệu
            </a>
            <a href="#rooms" className="text-foreground hover:text-primary transition-colors">
              Phòng
            </a>
            <a href="#amenities" className="text-foreground hover:text-primary transition-colors">
              Tiện ích
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">
              Liên hệ
            </a>
          </nav>

          {/* CTA Button */}
          <button className="hidden md:block px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium">
            Đặt phòng
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            <a href="#about" className="block px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors">
              Giới thiệu
            </a>
            <a href="#rooms" className="block px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors">
              Phòng
            </a>
            <a
              href="#amenities"
              className="block px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
            >
              Tiện ích
            </a>
            <a href="#contact" className="block px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors">
              Liên hệ
            </a>
            <button className="w-full mt-4 px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium">
              Đặt phòng
            </button>
          </nav>
        )}
      </div>
    </header>
  )
}
