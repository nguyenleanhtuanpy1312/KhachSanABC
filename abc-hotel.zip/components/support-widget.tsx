"use client"

import { useState } from "react"
import { MessageCircle, Mail, Phone, HelpCircle, X } from "lucide-react"

export default function SupportWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [isChatOpen, setIsChatOpen] = useState(false)

  const botpressUrl =
    "https://cdn.botpress.cloud/webchat/v3.3/shareable.html?configUrl=https://files.bpcontent.cloud/2025/10/17/03/20251017032701-TKYCED3T.json"

  const supportOptions = [
    {
      icon: MessageCircle,
      label: "Chat với chúng tôi",
      description: "Trò chuyện trực tiếp với đội hỗ trợ",
      action: () => {
        setIsChatOpen(true)
        setIsOpen(false)
      },
    },
    {
      icon: Phone,
      label: "Gọi cho chúng tôi",
      description: "+84 (0) 123 456 789",
      action: () => {
        window.location.href = "tel:+84123456789"
      },
    },
    {
      icon: Mail,
      label: "Gửi email",
      description: "support@hotelabcvn.com",
      action: () => {
        window.location.href = "mailto:support@hotelabcvn.com"
      },
    },
    {
      icon: HelpCircle,
      label: "Câu hỏi thường gặp",
      description: "Xem các câu hỏi phổ biến",
      action: () => {
        document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" })
        setIsOpen(false)
      },
    },
  ]

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Modal with Botpress iframe */}
      {isChatOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-end z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-md h-96 flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Chat với Hotel ABC</h3>
              <button
                onClick={() => setIsChatOpen(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <iframe src={botpressUrl} className="flex-1 w-full border-0" title="Hotel ABC Support Chat" />
          </div>
        </div>
      )}

      {/* Support Menu */}
      {isOpen && (
        <div className="absolute bottom-20 right-0 w-80 bg-white rounded-lg shadow-2xl p-4 mb-4 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Hỗ trợ khách hàng</h3>
            <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-700 transition-colors">
              <X size={20} />
            </button>
          </div>

          <div className="space-y-3">
            {supportOptions.map((option, index) => {
              const Icon = option.icon
              return (
                <button
                  key={index}
                  onClick={option.action}
                  className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-amber-50 transition-colors text-left group"
                >
                  <div className="flex-shrink-0 mt-1">
                    <Icon className="w-5 h-5 text-amber-700 group-hover:text-amber-900 transition-colors" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 group-hover:text-amber-900 transition-colors">
                      {option.label}
                    </p>
                    <p className="text-sm text-gray-600 truncate">{option.description}</p>
                  </div>
                </button>
              )
            })}
          </div>

          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center">Chúng tôi sẵn sàng hỗ trợ bạn 24/7</p>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-700 to-amber-900 text-white shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-200 flex items-center justify-center group relative"
      >
        {isOpen ? (
          <X size={24} />
        ) : (
          <>
            <MessageCircle size={24} />
            <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full animate-pulse"></span>
          </>
        )}
      </button>
    </div>
  )
}
