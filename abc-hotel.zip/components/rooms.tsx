import { ChevronRight } from "lucide-react"

const rooms = [
  {
    id: 1,
    name: "Phòng Tiêu Chuẩn",
    price: "2,500,000",
    image: "/luxury-hotel-standard-room.png",
    features: ["40m²", "Giường đôi", "Tầm nhìn thành phố"],
  },
  {
    id: 2,
    name: "Phòng Deluxe",
    price: "4,500,000",
    image: "/luxury-hotel-deluxe-room.png",
    features: ["60m²", "Giường King", "Ban công riêng"],
  },
  {
    id: 3,
    name: "Phòng Suite",
    price: "7,500,000",
    image: "/luxury-hotel-suite-room.jpg",
    features: ["100m²", "Phòng khách riêng", "Jacuzzi"],
  },
]

export default function Rooms() {
  return (
    <section id="rooms" className="py-20 bg-muted/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm tracking-widest uppercase">Các phòng của chúng tôi</span>
          <h2 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mt-4 text-balance">
            Chọn phòng phù hợp với bạn
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {rooms.map((room) => (
            <div
              key={room.id}
              className="bg-background rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
            >
              <img src={room.image || "/placeholder.svg"} alt={room.name} className="w-full h-64 object-cover" />
              <div className="p-6">
                <h3 className="text-2xl font-serif font-bold text-foreground mb-2">{room.name}</h3>
                <p className="text-primary font-bold text-xl mb-4">{room.price}đ/đêm</p>

                <ul className="space-y-2 mb-6">
                  {room.features.map((feature, idx) => (
                    <li key={idx} className="text-muted-foreground flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium flex items-center justify-center gap-2">
                  Xem chi tiết
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
