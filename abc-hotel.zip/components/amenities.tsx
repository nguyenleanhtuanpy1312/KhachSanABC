import { Wifi, Utensils, Dumbbell, Waves, ConciergeBell as Concierge, Tv } from "lucide-react"

const amenities = [
  {
    icon: Wifi,
    name: "WiFi Miễn phí",
    description: "Kết nối internet tốc độ cao trong toàn bộ khách sạn",
  },
  {
    icon: Utensils,
    name: "Nhà hàng 5 sao",
    description: "Ẩm thực quốc tế và địa phương từ các đầu bếp hàng đầu",
  },
  {
    icon: Dumbbell,
    name: "Phòng tập Gym",
    description: "Trang thiết bị hiện đại và huấn luyện viên chuyên nghiệp",
  },
  {
    icon: Waves,
    name: "Hồ bơi ngoài trời",
    description: "Hồ bơi Olympic với tầm nhìn toàn cảnh thành phố",
  },
  {
    icon: Concierge,
    name: "Dịch vụ Concierge",
    description: "Hỗ trợ 24/7 cho mọi nhu cầu của bạn",
  },
  {
    icon: Tv,
    name: "Giải trí",
    description: "TV 4K, phim, nhạc và trò chơi trên nhu cầu",
  },
]

export default function Amenities() {
  return (
    <section id="amenities" className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm tracking-widest uppercase">Tiện ích</span>
          <h2 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mt-4 text-balance">
            Những tiện ích hạng nhất
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {amenities.map((amenity, idx) => {
            const Icon = amenity.icon
            return (
              <div key={idx} className="p-8 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-4">
                  <Icon size={24} className="text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{amenity.name}</h3>
                <p className="text-muted-foreground">{amenity.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
