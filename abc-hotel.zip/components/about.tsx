import { Star } from "lucide-react"

export default function About() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className="relative">
            <img src="/luxury-hotel-room-elegant.jpg" alt="ABC Hotel Room" className="rounded-lg shadow-lg" />
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-lg shadow-lg">
              <div className="flex items-center gap-2">
                <Star size={24} fill="currentColor" />
                <div>
                  <p className="font-bold text-lg">5 Sao</p>
                  <p className="text-sm opacity-90">Đánh giá hàng đầu</p>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div>
            <span className="text-primary font-medium text-sm tracking-widest uppercase">Về chúng tôi</span>
            <h2 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mt-4 mb-6 text-balance">
              Trải nghiệm sang trọng không tưởng
            </h2>
            <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
              ABC Hotel là biểu tượng của sự sang trọng và tinh tế. Với hơn 20 năm kinh nghiệm, chúng tôi cam kết mang
              đến cho khách hàng những trải nghiệm tuyệt vời nhất.
            </p>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Mỗi phòng được thiết kế với sự chú ý đến từng chi tiết, kết hợp công nghệ hiện đại với nội thất cổ điển,
              tạo nên một không gian hoàn hảo để thư giãn.
            </p>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-3xl font-bold text-primary">250+</p>
                <p className="text-sm text-muted-foreground">Phòng</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">20+</p>
                <p className="text-sm text-muted-foreground">Năm kinh nghiệm</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">98%</p>
                <p className="text-sm text-muted-foreground">Hài lòng</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
