"use client"

import { useEffect } from "react"

export default function Chatbot() {
  useEffect(() => {
    const script = document.createElement("script")
    script.src = "https://cdn.botpress.cloud/webchat/v3.3/shareable.html"
    script.async = true
    script.onload = () => {
      // Initialize Botpress webchat
      if (window.botpressWebChat) {
        window.botpressWebChat.init({
          configUrl: "https://files.bpcontent.cloud/2025/10/17/03/20251017032701-TKYCED3T.json",
        })
      }
    }
    document.body.appendChild(script)

    return () => {
      // Cleanup script on unmount
      const scripts = document.querySelectorAll('script[src="https://cdn.botpress.cloud/webchat/v3.3/shareable.html"]')
      scripts.forEach((s) => s.remove())
    }
  }, [])

  return null
}
