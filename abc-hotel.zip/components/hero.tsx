"use client"

import { ChevronRight, Sparkles } from "lucide-react"
import { useState } from "react"

export default function Hero() {
  const [isHovering, setIsHovering] = useState(false)

  return (
    <section className="relative w-full min-h-screen bg-background pt-20 flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url(/luxury-hotel-room-elegant.jpg)",
        }}
      />

      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50" />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-20">
        <div className="mb-8 flex items-center justify-center gap-2">
          <div className="h-px w-8 bg-gradient-to-r from-transparent to-amber-400" />
          <span className="text-amber-400 font-light text-sm tracking-widest uppercase">Khám phá sự sang trọng</span>
          <div className="h-px w-8 bg-gradient-to-l from-transparent to-amber-400" />
        </div>

        <h1 className="text-6xl sm:text-7xl lg:text-8xl font-serif font-bold text-white mb-8 text-balance leading-tight">
          ABC Hotel
        </h1>

        <p className="text-lg sm:text-xl lg:text-2xl text-gray-100 mb-12 max-w-3xl mx-auto text-balance font-light leading-relaxed">
          Nơi mỗi khoảnh khắc trở thành một kỷ niệm vô giá. Trải nghiệm dịch vụ 5 sao với sự chăm sóc tận tâm và tinh
          tế.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button
            onMouseEnter={() => setIsHovering(true)}
            onMouseLeave={() => setIsHovering(false)}
            className="px-10 py-4 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-all duration-300 font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl hover:scale-105"
          >
            Đặt phòng ngay
            <ChevronRight size={20} className={`transition-transform ${isHovering ? "translate-x-1" : ""}`} />
          </button>
          <button className="px-10 py-4 border-2 border-white text-white rounded-lg hover:bg-white/10 transition-all duration-300 font-semibold backdrop-blur-sm">
            Tìm hiểu thêm
          </button>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-white/80 text-sm">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-amber-400" />
            <span>Đạt giải thưởng quốc tế</span>
          </div>
          <div className="hidden sm:block w-px h-4 bg-white/30" />
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-amber-400" />
            <span>Phục vụ hơn 50,000 khách hàng</span>
          </div>
          <div className="hidden sm:block w-px h-4 bg-white/30" />
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-amber-400" />
            <span>Đánh giá 4.9/5 sao</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-amber-400 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-amber-400 rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  )
}
